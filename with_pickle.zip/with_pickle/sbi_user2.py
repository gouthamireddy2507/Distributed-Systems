import socket
import pickle

def send_request(host, port, request):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as client_socket:
        client_socket.connect((host, port))
        client_socket.sendall(pickle.dumps(request))
        response_bytes = client_socket.recv(1024)
        response = pickle.loads(response_bytes)
        return response

if __name__ == "__main__":
    host = "127.0.0.1"
    port = 8080

    while True:
        print("\n1. Deposit\n2. Withdraw\n3. List Transactions\n4. Get Balance\n5. Exit")
        choice = input("Enter your choice (1-5): ")

        if choice == "1":
            desc = input("Enter description: ")
            amount = float(input("Enter amount to deposit: "))
            response = send_request(host, port, {"operation": "deposit", "params": {"desc": desc, "amount": amount}})
            message = response.get("message", "Invalid response")
            print(message)

        elif choice == "2":
            desc = input("Enter description: ")
            amount = float(input("Enter amount to withdraw: "))
            response = send_request(host, port, {"operation": "withdraw", "params": {"desc": desc, "amount": amount}})
            message = response.get("message", "Invalid response")
            print(message)

        elif choice == "3":
            num_transactions = int(input("Enter the number of transactions to list: "))
            response = send_request(host, port, {"operation": "list_transactions", "params": {"num_transactions": num_transactions}})
            transactions = response if isinstance(response, list) else []
            print("List of Transactions:")
            for transaction in transactions:
                print(transaction)

        elif choice == "4":
            response = send_request(host, port, {"operation": "get_balance"})
            balance = response.get("balance", None)
            print(f"\nCurrent Balance: {balance}")

        elif choice == "5":
            print("Exiting...")
            break

        else:
            print("Invalid choice. Please enter a number between 1 and 5.")