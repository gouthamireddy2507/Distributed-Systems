import unittest
import threading
import time
from sbi_server2 import SBI_Passbook, serve, process_request
from sbi_user2 import send_request

class TestSBI_Passbook(unittest.TestCase):
    def setUp(self):
        self.sbi_passbook = SBI_Passbook()
        self.server_thread = threading.Thread(target=serve, args=(self.sbi_passbook, "127.0.0.1", 8080))
        self.server_thread.daemon = True
        self.server_thread.start()
        time.sleep(1) 

    def tearDown(self):
        self.server_thread.join()

    def test_deposit(self):
        response = send_request("127.0.0.1", 8080, {"operation": "deposit", "params": {"desc": "Salary", "amount": 5000}})
        self.assertEqual(response['success'], True)
        self.assertEqual(response['message'], "Deposit successful!")

    def test_withdraw(self):
        send_request("127.0.0.1", 8080, {"operation": "deposit", "params": {"desc": "Salary", "amount": 5000}})
        
        response = send_request("127.0.0.1", 8080, {"operation": "withdraw", "params": {"desc": "Groceries", "amount": 2000}})
        self.assertEqual(response['success'], True)
        self.assertEqual(response['message'], "Withdrawal successful!")

    def test_get_balance(self):
        send_request("127.0.0.1", 8080, {"operation": "deposit", "params": {"desc": "Salary", "amount": 5000}})
        response = send_request("127.0.0.1", 8080, {"operation": "get_balance"})
        self.assertEqual(response['balance'], 5000)

if __name__ == '__main__':
    unittest.main()
