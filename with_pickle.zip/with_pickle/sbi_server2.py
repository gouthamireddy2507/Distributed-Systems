import socket
import pickle
from multiprocessing import Lock
from datetime import datetime

class SBI_Passbook:
    def __init__(self):
        self.transactions = []
        self.balance = 0
        self.lock = Lock()

    def deposit(self, desc, amount):
        with self.lock:
            if amount < 0:
                return {"error": "Deposit amount cannot be negative."}

            transaction = ["Deposit", desc, amount, str(datetime.now())]
            self.transactions.append(transaction)
            self.balance += amount
            return {"success": True, "message": f"Deposit successful! Transaction: {transaction}", "balance": self.balance}

    def withdraw(self, desc, amount):
        with self.lock:
            if amount < 0:
                return {"error": "Withdrawal amount cannot be negative."}

            if amount > self.balance:
                return {"error": "Withdrawal amount exceeds current balance. Withdrawal not allowed."}

            transaction = ["Withdrawal", desc, amount, str(datetime.now())]
            self.transactions.append(transaction)
            self.balance -= amount
            return {"success": True, "message": f"Withdrawal successful! Transaction: {transaction}", "balance": self.balance}

    def list_transactions(self, num_transactions=None):
        with self.lock:
            if num_transactions:
                return self.transactions[-num_transactions:]
            else:
                return self.transactions

    def get_balance(self):
        with self.lock:
            return self.balance

def serve(passbook, host, port):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server_socket:
        server_socket.bind((host, port))
        server_socket.listen()

        print(f"Server listening on {host}:{port}")

        while True:
            conn, addr = server_socket.accept()
            with conn:
                print(f"Connected by {addr}")
                data = conn.recv(1024)
                if not data:
                    break

                request = pickle.loads(data)
                response = process_request(passbook, request)

                conn.sendall(pickle.dumps(response))

def process_request(passbook, request):
    operation = request["operation"]
    params = request.get("params", {})

    if operation == "deposit":
        desc = params.get("desc", "")
        amount = params.get("amount", 0)
        return passbook.deposit(desc, amount)

    elif operation == "withdraw":
        desc = params.get("desc", "")
        amount = params.get("amount", 0)
        return passbook.withdraw(desc, amount)

    elif operation == "list_transactions":
        num_transactions = params.get("num_transactions", None)
        return passbook.list_transactions(num_transactions)

    elif operation == "get_balance":
        return {"balance": passbook.get_balance()}

    else:
        return {"error": "Invalid operation"}

if __name__ == "__main__":
    sbi_passbook = SBI_Passbook()
    serve(sbi_passbook, "127.0.0.1", 8080)